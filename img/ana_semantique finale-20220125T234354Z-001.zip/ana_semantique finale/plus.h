#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "analyseSyntaxique.tab.h"
int yylex(void);
void yyerror(char*);